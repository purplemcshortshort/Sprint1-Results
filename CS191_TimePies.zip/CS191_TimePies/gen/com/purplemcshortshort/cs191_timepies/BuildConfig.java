/** Automatically generated file. DO NOT MODIFY */
package com.purplemcshortshort.cs191_timepies;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}