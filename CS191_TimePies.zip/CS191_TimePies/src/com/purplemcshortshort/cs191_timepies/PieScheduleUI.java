/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Patricia Kelly D. Co
 * @author Kenneth T. Otsuka
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Patricia Kelly D. Co
 * @since 2014-11-13
 * Initial code.
 * @version 1.1
 * @author Kenneth T. Otsuka
 * @since 2014-02-06
 * Added Set Time functionality.
 * @author Patricia Kelly D. Co
 * @since 2014-02-10
 * Changed Button setTimeButton, startButton, and resetButton to ImageButton.
 * Added an onClickListener for startButton. 
 * Changed the layout design.
 */
/**
 * Created on 2014-11-13
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * The Boundary Class of the application.
 */

package com.purplemcshortshort.cs191_timepies;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
/**
 * Handles the displaying of all UI.  
 *
 */
public class PieScheduleUI extends Activity{
     private Context context;     
     private PieSchedule pieSchedule;
     
     private ImageButton setTimeButton;
     private ImageButton resetButton;
     private ImageButton startButton;
    
     private View view;
     private LayoutInflater inflater;
     private Chronometer chrome;
     private CountDownTimer countDown;
     private TimePicker timePicker;
     private int startHour;
     private int endHour;
     private int startMinute;
     private int endMinute;
     private int finalHour;
     private int finalMinute;
     private int finalSecond;
     private long remainingTime;
     private boolean isTimeSet = false;
     private SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
     
     /**
      * onCreate
      *  - This is the onCreate method that starts up the TimePies.
      * @since 2015-02-10
      * @param savedInstanceState Saves the state upon call
      * @return void
      * @exception InterruptedException
      */
     @Override
     protected void onCreate(Bundle savedInstanceState){
          super.onCreate(savedInstanceState);
          
          setContentView(R.layout.activity_main);
          context = this;
          
          PieScheduleDao.context = context;
         
          setTimeButton = (ImageButton)findViewById(R.id.setTimeButton);
          setTimeButtonOnClickListeners();
          
          startButton = (ImageButton)findViewById(R.id.startButton);
          startButtonOnClickListeners();
          
          resetButton = (ImageButton)findViewById(R.id.resetButton);
          
          /*init pie schedule, create from source file*/
          pieSchedule = PieScheduleController.initPieSchedule();
          
          chrome = (Chronometer) findViewById(R.id.chronometer);
          String remTimes = pieSchedule.getRemTime();
          String[] hourMinSec = remTimes.split(":");
          finalHour = Integer.parseInt(hourMinSec[0]);
          finalMinute = Integer.parseInt(hourMinSec[1]);
          finalSecond = Integer.parseInt(hourMinSec[2]);
          chrome.setText("" + timeFormat.format(computeRemainingTime()));    
          inflater = ((Activity)context).getLayoutInflater();
     }
     
     /**
      * startButtonOnClickListeners
      *  - Called when startButton is clicked. Starts the count down timer.
      * @since 2015-02-10
      * @return void
      * @param void 
      */
     private void startButtonOnClickListeners(){
          startButton.setOnClickListener(new ImageButton.OnClickListener(){
               public void onClick(View view){
                    if(isTimeSet){
                         countDownToZero();
                         startCountDownToZero();
                    } 
               }
                
          });
     }
     
     /**
      * setTimeButtonOnClickListeners
      *  - Called when setTimeButton has been clicked. Lets user choose between
      *    setting start-end time or setting duration.
      * @since 2015-02-06
      * @param void
      * @return void
      */
     private void setTimeButtonOnClickListeners(){
          setTimeButton.setOnClickListener(new ImageButton.OnClickListener(){
               public void onClick(View view){	
                    final CharSequence[] timeChoice = {" Set Start-End Time "," Set Duration "};
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle("Choose type on time input:");
                    builder.setItems(timeChoice, new DialogInterface.OnClickListener(){
                         public void onClick(DialogInterface dialog, int item){
                              switch(item){
                              case 0:
                                   /* Set Start and End Time is selected */
                                   dialog.dismiss();
                                   setStartTime();
                                   break;
                              case 1:
                                   /* Duration is selected */
                                   dialog.dismiss();
                                   setDuration();
                                   break;
                              }
                              dialog.dismiss();
                         }
                    });
                    AlertDialog alert = builder.create();
                    alert.show();
               }
          });
     }
     
     /**
      * setStartTime
      *  - Set the start time of your Pie Schedule. Automatically calls {@link #setEndTime()}.
      * @since 2015-02-06
      * @param void
      * @return void
      */
     public void setStartTime(){
          AlertDialog.Builder builder = new AlertDialog.Builder(context);
          builder.setTitle("Set Time Start:");
          timePicker = new TimePicker(context);
          timePicker.setIs24HourView(true);
          timePicker.setCurrentHour(0);
          timePicker.setCurrentMinute(0);
          builder.setView(timePicker);
          builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
               public void onClick(DialogInterface dialog, int id){
                    startHour= timePicker.getCurrentHour();
                    startMinute = timePicker.getCurrentMinute();
                    dialog.cancel();
                    setEndTime();
               }
          });
          builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
               public void onClick(DialogInterface dialog, int id){
                    dialog.cancel();
               }
          });
          AlertDialog alert = builder.create();
          alert.show();
     }
     
     /**
      * setEndTime
      *  - Set the end time of your Pie Schedule.
      * @since 2015-02-06
      * @param void
      * @return void
      */
     public void setEndTime(){
     AlertDialog.Builder builder = new AlertDialog.Builder(context);
          builder.setTitle("Set Time End:");
          timePicker = new TimePicker(context);
          timePicker.setIs24HourView(true);
          timePicker.setCurrentHour(0);
          timePicker.setCurrentMinute(0);
          builder.setView(timePicker);
          builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
               public void onClick(DialogInterface dialog, int id){
                    endHour = timePicker.getCurrentHour();
                    endMinute = timePicker.getCurrentMinute();
                    dialog.cancel();
                    getTimeDifference();
                    isTimeSet = true;
                    chrome = (Chronometer) findViewById(R.id.chronometer);
                    chrome.setText("" + timeFormat.format(computeRemainingTime()));
                    PieScheduleController.setTime(pieSchedule,startHour+":"+startMinute+":"+"00",endHour+":"+endMinute+":"+"00", finalHour+":"+finalMinute+":"+"00");
               }
          });
          builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
               public void onClick(DialogInterface dialog, int id){
                    dialog.cancel();
               }
          });
          AlertDialog alert = builder.create();
          alert.show();
     }
     
     /**
      * getTimeDifference
      *  - Get the time duration of your Pie Schedule 
      *    from {@link #setStartTime()} to {@link #setEndTime()}.
      * @since 2015-02-06
      * @param void
      * @return void
      */
     public void getTimeDifference(){
          finalHour = endHour - startHour;
          finalMinute = endMinute - startMinute;
     }
     
     /**
      * setDuration
      *  - Set the time duration of your Pie Schedule.
      * @since 2015-02-06
      * @param void
      * @return void
      */
     public void setDuration(){
          AlertDialog.Builder builder = new AlertDialog.Builder(context);
          builder.setTitle("Set Duration:");
          timePicker = new TimePicker(context);
          timePicker.setIs24HourView(true);
          timePicker.setCurrentHour(0);
          timePicker.setCurrentMinute(0);
          builder.setView(timePicker);
          builder.setPositiveButton("Okay", new DialogInterface.OnClickListener(){
               public void onClick(DialogInterface dialog, int id){
                    finalHour = timePicker.getCurrentHour();
                    finalMinute = timePicker.getCurrentMinute();
                    dialog.cancel();
                    isTimeSet = true;
                    chrome = (Chronometer) findViewById(R.id.chronometer);
                    chrome.setText("" + timeFormat.format(computeRemainingTime()));
                    
                    PieScheduleController.setTime(pieSchedule, "??:??:??", "??:??:??", finalHour+":"+finalMinute+":"+"00");
               }
          });
          builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener(){
               public void onClick(DialogInterface dialog, int id){
                    dialog.cancel();
               }
          });
          AlertDialog alert = builder.create();
          alert.show();
     }
     
     /**
      * countDownToZero
      *  - Sets the text of the Chronometer into the duration of the Pie Schedule.
      * @since 2015-02-06
      * @param void
      * @return void
      */
     private void countDownToZero(){
          chrome = (Chronometer) findViewById(R.id.chronometer);
          Toast.makeText(getApplicationContext(), Long.toString(computeRemainingTime()/1000) + " seconds", Toast.LENGTH_SHORT).show();
          countDown = new CountDownTimer(computeRemainingTime(), 1000){
               public void onTick(long millisUntilFinished) {
                    chrome.setText("" + timeFormat.format(millisUntilFinished));
               }
               public void onFinish(){
                    chrome.setText("Time's up!");
               }
          };
     }
     
     /**
      * startCountDownToZero
      *  - Starts the countdown timer.
      * @since 2015-02-06
      * @param void
      * @return void
      */
     private void startCountDownToZero(){
          countDown.start(); 
     }
     
     /**
      * computeRemainingTime
      *  - Computes the remaining time for every instance.
      * @since 2015-02-06
      * @param void
      * @return void
      */
     private long computeRemainingTime(){
          remainingTime = ((finalHour * 3600) + (finalMinute * 60) +finalSecond);
          return remainingTime * 1000;
     }
}