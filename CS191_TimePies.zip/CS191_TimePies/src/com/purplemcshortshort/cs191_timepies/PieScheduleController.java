/**
 * REVISED BSD LICENSE
 * Copyright (c) 2015, Patricia Kelly D. Co, Kenneth T. Otsuka, Mary Jane T. Rubio
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Patricia Kelly Co, Mary Jane T. Rubio, and 
 * Kenneth T. Otsuka BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY 
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * @author Mary Jane T. Rubio
 * This is a course requirement for CS 192 Software Eng'g II under the supervision of 
 * Prof. Ma. Rowena C. Solamo of the Department of Computer Science, College of Engineering, 
 * University of the Philippines, Diliman for AY 2014-2015.
 */
/**
 * Code History
 * @version 1.0
 * @author Mary Jane T. Rubio
 * @since 2015-11-20
 * Initial code.
 * @version 1.1
 * @author Mary Jane T. Rubio
 * @since 2015-02-10
 * Changed initPieSchedule(), returns a PieSchedule instead of void
 * Added method setTime(PieSchedule,String,String,String)
 */
/**
 * Created on 2014-11-20
 * Developed by Purple McShortShort
 * Client Pink PlastiCS
 * The controller for the application's boundary, object and DAO classes.
 */
package com.purplemcshortshort.cs191_timepies;

import java.util.*;
import android.content.Context;
/**
 * Contains methods that connects the boundary, object, and DAO classes for the PieSchedule.
 *
 */
public class PieScheduleController {
     /**
      * initPieSchedule
      *  - Creates the saved PieSchedule
      * @since 2014-11-20
      * @param void
      * @return ps The PieSchedule to be initialized
      */
     public static PieSchedule initPieSchedule(){
          PieSchedule ps = PieScheduleDao.read();
          return ps;
     }
     
     /**
      * reset
      *  - Sets all the times to 00:00:00 and deletes all the slices. Calls PieScheduleDao.write(PieSchedule) to save its state.
      * @since 2014-11-20
      * @param ps The PieSchedule to be reset (PieSchedule)
      * @return void
      */
     public static void reset(PieSchedule ps){
          ps.setStartTime("00:00:00");
          ps.setEndTime("00:00:00");
          ps.setRemTime("00:00:00");
          while(ps.getSize()>0)
               ps.deleteSlice(0);
          PieScheduleDao.write(ps);
     }
     
     /**
      * setTime
      *  - Sets the time based on the user input
      * @since 2015-02-10
      * @param ps The PieSchedule (PieSchedule)
      * @param st Start time (String)
      * @param et End time (String)
      * @param rt Remaining time or duration (String)
      * @return void
      */
     public static void setTime(PieSchedule ps, String st, String et, String rt){
    
          ps.setStartTime(st);
          ps.setEndTime(et);
          ps.setRemTime(rt);
          PieScheduleDao.write(ps);
     }
}